README.txt      K. J. Turner    28th September 2015

This is version 1.7 of Jasper (Java Simulation of Protocols for Education and
Research): https://sourceforge.net/projects/jaspersimulator.

Open "html/index.html" in a web browser to try out the protocol simulations.
(Due to Java security restrictions you must authorise running of code created by
the University of Stirling.)

Open "docs/index.html" in a web browser for more detail and the licence
conditions.

Note that simulations of CSMA/CD, Multicast, Multiplexing, Protocol Stack and
TCP Slow Start were created for Pearson Education to accompany the ninth edition
of "Data and Computer Communications" by William Stallings.

