// STACKSdu.java

package protocol;				// protocol package

import support.*;				// import Jasper support classes

/**
  This is the class that defines SDUs for a protocol stack.

  @author	Kenneth J. Turner
  @version	1.0 (23rd July 2010, KJT): initial version
*/

public class STACKSdu extends PDU {

  /** Service SDU type */
  public final static String TYPE = "DATA";

  /** Service message */
  public String sdu;

  /**
    Constructor for a source/sink service message.

    @param sdu		SDU data
  */
  public STACKSdu(String sdu) {
    super(TYPE);				// construct with type
    this.sdu = sdu;				// set SDU data
  }

  /**
    Return the label for an arrow representing a protocol stack SDU in a time
    sequence diagram.

    @return		the label name
  */
  public String getLabel() {
    return type + "(" + sdu + ")";
  }

  /**
    Return the SDU.

    @return		SDU
  */
  public String getSDU() {
    return(sdu);
  }

  /**
    Return the SDU.

    @param sdu		SDU
  */
  public void setSDU(String sdu) {
    this.sdu = sdu;
  }

  /**
    Convert SDU to string.

    @return		SDU as string
  */
  public String toString() {
    return("SDU <Type " + type + ", Data " + sdu + ">");
  }

}

