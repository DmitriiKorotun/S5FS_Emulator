// HTTPSender.java

package protocol;				// protocol package

import java.util.*;				// import Java utility classes

import support.*;				// import Jasper support classes

/**
  This is the main class for simulation of HTTP.

  @author	Kenneth J. Turner, Kenneth A. Whyte
  @version	1.4 (9th March 2006, KJT/KAW): initial version
  <br/>		1.5 (19th July 2010, KJT): minor tidying
*/

public class HTTP extends Protocol {

  private HTTPSender sender;
  private HTTPReceiver receiver;

  public HTTP() {
    medium = new Medium();
    sender = new HTTPSender(medium, "Client");
    receiver = new HTTPReceiver(medium, "Server");
    sender.setPeer(receiver);
    receiver.setPeer(sender);
    entities = new Vector<ProtocolEntity>();
    entities.addElement(sender);
    entities.addElement(medium);
    entities.addElement(receiver);
  }

}
