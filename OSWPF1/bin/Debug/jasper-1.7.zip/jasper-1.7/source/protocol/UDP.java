// UDP.java	(C) I. A. Robin, K. J. Turner	04/03/06

package protocol;

import java.util.*;
import support.*;

public class UDP extends Protocol {

  private UDPService userA;
  private UDPService userB;
  private UDPProtocol protA;
  private UDPProtocol protB;

  public UDP() {
    medium = new UDPMedium();
    userA = new UDPService("User A");
    userB = new UDPService("User B");
    protA = new UDPProtocol(medium, "Protocol A");
    protB = new UDPProtocol(medium, "Protocol B");
    userA.setProvider(protA);
    userB.setProvider(protB);
    protA.setUser(userA);
    protA.setPeer(protB);
    protB.setUser(userB);
    protB.setPeer(protA);
    entities = new Vector<ProtocolEntity>();
    entities.addElement(userA);
    entities.addElement(protA);
    entities.addElement(medium);
    entities.addElement(protB);
    entities.addElement(userB);
    userA.setSourcePort(1111);			// initialise A source
    userA.setDestPort(2222);			// initialise A destination
    userB.setSourcePort(3333);			// initialise B source
    userB.setDestPort(4444);			// initialise B destination
  }

  public void setParameter(String param, String value) {
    try {
      int port = Integer.parseInt(value);
      if (param.equals("sourcePortA"))
	userA.setSourcePort(port);
      if (param.equals("destPortA"))
	userA.setDestPort(port);
      if (param.equals("sourcePortB"))
	userB.setSourcePort(port);
      if (param.equals("destPortB"))
	userB.setDestPort(port);
    }
    catch (NumberFormatException e) {}
  }
}
