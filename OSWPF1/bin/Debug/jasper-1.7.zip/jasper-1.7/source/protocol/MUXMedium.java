// MUXMedium.java

package protocol;				// protocol package

import support.*;				// import Jasper support classes

/**
  This is the class that defines the channel between (de)multiplexers.

  @author	Kenneth J. Turner
  @version	1.0 (20th July 2010): initial version
*/

public class MUXMedium extends Medium {

  /** Medium name */
  private final static String NAME = "Channel";

  /**
    Gets the medium name.

    @return	medium name
  */
  public String getName() {
    return(NAME);
  }

}

