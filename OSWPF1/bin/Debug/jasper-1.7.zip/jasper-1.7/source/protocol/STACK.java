// STACK.java

package protocol;				// protocol package

import java.util.*;				// import Java utility classes

import support.*;				// import Jasper support classes

/**
  This is the main class for simulation of a protocol stack.

  @author	Kenneth J. Turner
  @version	1.0 (20th July 2010, KJT): initial version
*/
public class STACK extends Protocol {

  /** Application layer */
  private STACKApplication userA;

  /** Transport layer */
  private STACKTransport userB;

  /** Network layer */
  private STACKNetwork userC;

  /** Data link layer */
  private STACKDataLink userD;

  /** Physical layer */
  private STACKPhysical userE;

  /** Medium */
  private STACKMedium medium;

  /**
    Constructor for a STACK object.
  */
  public STACK() {
    userA = new STACKApplication("Application");// create application layer
    userB = new STACKTransport("Transport");	// create transport layer
    userC = new STACKNetwork("Network");	// create network layer
    userD = new STACKDataLink("Data Link");	// create data link layer
    userE = new STACKPhysical("Physical");	// create physical layer
    medium = new STACKMedium();			// create medium

    userA.setProvider(userB);			// set application->transport
    userB.setProvider(userC);			// set transport->network
    userC.setProvider(userD);			// set network->data link
    userD.setProvider(userE);			// set data link->physical
    userE.setProvider(medium);			// set physical->medium

    userB.setUser(userA);			// set transport->application
    userC.setUser(userB);			// set network->transport
    userD.setUser(userC);			// set data link->network
    userE.setUser(userD);			// set physical->data link
    medium.setUser(userE);			// set medium->physical

    entities = new Vector<ProtocolEntity>();	// create entity list
    entities.addElement(userA);			// add application layer
    entities.addElement(userB);			// add transport layer
    entities.addElement(userC);			// add network layer
    entities.addElement(userD);			// add data link layer
    entities.addElement(userE);			// add physical layer
    entities.addElement(medium);		// add medium
  }

}

