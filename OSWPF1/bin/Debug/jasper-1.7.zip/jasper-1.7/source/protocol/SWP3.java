// SWP3.java	(C) I. A. Robin, K. J. Turner	08/03/06

package protocol;

import java.util.*;
import support.*;

public class SWP3 extends Protocol {

  private int maxSeq = 7;
  private int winSize = 3;
  private SWP3Sender sender;
  private SWP3Receiver receiver;

  public SWP3() {
    medium = new Medium();
    sender = new SWP3Sender(maxSeq, winSize, medium);
    receiver = new SWP3Receiver(maxSeq, winSize, medium);
    sender.setPeer(receiver);
    receiver.setPeer(sender);
    entities = new Vector<ProtocolEntity>();
    entities.addElement(sender);
    entities.addElement(medium);
    entities.addElement(receiver);
  }

  public void setParameter(String param, String value) {
    super.setParameter(param, value);
    try {
      if (param.equals("maxSeq")) {
	maxSeq = Integer.parseInt(value);
	sender.setMaxSeq(maxSeq);
	receiver.setMaxSeq(maxSeq);
      }
      else if (param.equals("winSize")) {
	winSize = Integer.parseInt(value);
	sender.setWindowSize(winSize);
	receiver.setWindowSize(winSize);
      }
    }
    catch (NumberFormatException e) {}
  }

}
