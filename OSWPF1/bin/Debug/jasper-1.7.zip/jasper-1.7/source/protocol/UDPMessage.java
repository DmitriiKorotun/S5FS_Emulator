// UDPMessage.java	(C) I. A. Robin, K. J. Turner	01/03/01

package protocol;

import support.*;

public class UDPMessage extends PDU {

  // Class representing User Datagram Protocol Data Unit

  int sourcePort = -1;
  int destPort = -1;

  public UDPMessage(String type, int sp, int dp) {
    super(type);
    sourcePort = sp;
    destPort = dp;
  }

  public UDPMessage(String type, int sp, int dp, String sdu) {
    super(type, sdu);
    sourcePort = sp;
    destPort = dp;
  }

  public boolean matches(PDU pdu) {
    if (pdu == null) return false;
    UDPMessage ud = (UDPMessage)pdu;
    if (type.equals(ud.type) && source == ud.getSource()) {
      if (sourcePort == ud.sourcePort
          && destPort == ud.destPort
          && sdu.equals(ud.getSDU()))
          return true;
    }
    return false;
  }

  // returns label for arrow representing UDP PDU in a time sequence diagram

  public String getLabel() {
    return type + "(" + sourcePort + "," + destPort+ "," + sdu + ")";
  }

}
