// TFTP.java	(C) K. J. Turner, K. A. Whyte	04/03/06

// Trivial File Transfer Protocol

package protocol;				// protocol package

import java.util.Vector;			// vector (list)
import support.*;				// protocol entity support

public class TFTP extends Protocol {		// TFTP protocol

  private TFTPSender sender;			// protocol sender (client)
  private TFTPReceiver receiver;		// protocol receiver (server)

  public TFTP() {				// construct protocol instance
    medium = new TFTPMedium();			// construct comms medium
    sender =					// construct sender (client)
      new TFTPSender(medium, "Client");
    receiver =					// construct receiver (server)
      new TFTPReceiver(medium, "Server");
    sender.setPeer(receiver);			// sender is receiver's peer
    receiver.setPeer(sender);			// receiver is sender's peer
    entities = new Vector<ProtocolEntity>();	// initialise protocol entities
    entities.addElement(sender);		// add sender protocol entity
    entities.addElement(medium);		// add comms medium entity
    entities.addElement(receiver);		// add receive protocol entity
  }

}
