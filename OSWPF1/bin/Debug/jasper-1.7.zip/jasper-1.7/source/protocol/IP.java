// IP.java	(C) I. A. Robin, K. J. Turner	04/03/06

package protocol;

import java.util.*;
import support.*;

public class IP extends Protocol {

  private IPService userA;
  private IPService userB;
  private IPProtocol protA;
  private IPProtocol protB;

  public IP() {
    medium = new IPMedium();
    userA = new IPService("User A");
    userB = new IPService("User B");
    protA = new IPProtocol(medium, "Protocol A");
    protB = new IPProtocol(medium, "Protocol B");
    userA.setProvider(protA);
    userB.setProvider(protB);
    protA.setUser(userA);
    protA.setPeer(protB);
    protB.setUser(userB);
    protB.setPeer(protA);
    entities = new Vector<ProtocolEntity>();
    entities.addElement(userA);
    entities.addElement(protA);
    entities.addElement(medium);
    entities.addElement(protB);
    entities.addElement(userB);
  }

  public void setParameter(String param, String value) {
    IPMedium ipMedium = (IPMedium)medium;
    if (param.equals("misordering")) {
      ipMedium.setMisordering(Boolean.valueOf(value).booleanValue());
      System.out.println(param + " set: " + value);
      return;
    }
    try {
      if (param.equals("lossRate")) {
	ipMedium.setLossRate(Float.valueOf(value).floatValue());
	System.out.println(param + " set: " + value);
	return;
      }
      int size = Integer.parseInt(value);
      if (param.equals("userMessageSize")) {
	userA.setMessageSize(size);
	userB.setMessageSize(size);
	System.out.println(param + " set: " + size);
	return;
      }
      if (param.equals("maxProtocolMessageSize")) {
	protA.setMaxMessageSize(size);
	protB.setMaxMessageSize(size);
	System.out.println(param + " set: " + size);
	return;
      }
      if (param.equals("maxMediumMessageSize")) {
	ipMedium.setMaxMessageSize(size);
	System.out.println(param + " set: " + size);
	return;
      }
    }
    catch (NumberFormatException e) {			// invalid number value
      System.out.println(param + " number format exception: " + value);
    }
  }

}
