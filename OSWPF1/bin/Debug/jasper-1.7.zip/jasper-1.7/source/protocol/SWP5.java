// SWP5.java	(C) I. A. Robin, K. J. Turner	04/03/06

package protocol;

import java.util.*;
import support.*;

public class SWP5 extends Protocol {

  private int maxSeq = 7;
  private int winSize = 3;
  private SWP5Service userA;
  private SWP5Service userB;
  private SWP5Sender sender;
  private SWP5Receiver receiver;

  public SWP5() {
    medium = new Medium();
    userA = new SWP5Service("User A", true);
    userB = new SWP5Service("User B", false);
    sender = new SWP5Sender(maxSeq, winSize, medium);
    receiver = new SWP5Receiver(maxSeq, winSize, medium);
    userA.setProvider(sender);
    userB.setProvider(receiver);
    sender.setUser(userA);
    receiver.setUser(userB);
    sender.setPeer(receiver);
    receiver.setPeer(sender);
    entities = new Vector<ProtocolEntity>();
    entities.addElement(userA);
    entities.addElement(sender);
    entities.addElement(medium);
    entities.addElement(receiver);
    entities.addElement(userB);
  }

  public void setParameter(String param, String value) {
    try {
      if (param.equals("maxSeq")) {
	maxSeq = Integer.parseInt(value);
	sender.setMaxSeq(maxSeq);
	receiver.setMaxSeq(maxSeq);
      }
      if (param.equals("winSize")) {
	winSize = Integer.parseInt(value);
	sender.setWindowSize(winSize);
	receiver.setWindowSize(winSize);
      }
    }
    catch (NumberFormatException e) {}
  }

}
