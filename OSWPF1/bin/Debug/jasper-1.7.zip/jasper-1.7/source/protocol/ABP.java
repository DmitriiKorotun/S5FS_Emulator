// ABRAServiceEntity.java	(C) I. A. Robin, K. J. Turner	08/03/06

package protocol;

import java.util.*;
import support.*;

public class ABP extends Protocol {

  private ABPSender sender;
  private ABPReceiver receiver;

  public ABP() {
    medium = new Medium();
    sender = new ABPSender(medium, "Sender");
    receiver = new ABPReceiver(medium, "Receiver");
    sender.setPeer(receiver);
    receiver.setPeer(sender);
    entities = new Vector<ProtocolEntity>();
    entities.addElement(sender);
    entities.addElement(medium);
    entities.addElement(receiver);
  }

}
