// MCASTSdu.java

package protocol;				// protocol package

import support.*;				// import Jasper support classes

/**
  This is the class that defines SDUs for broad/uni/multicast.

  @author	Kenneth J. Turner
  @version	1.0 (22nd July 2010, KJT): initial version
*/

public class MCASTSdu extends PDU {

  /** Service SDU type */
  public final static String TYPE = "DT";

  /** Service destinations (router letters) */
  public String destinations;

  /** Service message */
  public String sdu;

  /**
    Constructor for a broad/uni/multicast service message.

    @param destination		destination letter
    @param sdu			SDU data
  */
  public MCASTSdu(char destination, String sdu) {
    super(TYPE);				// construct with type
    this.destinations = destination + "";	// set SDU destinations
    this.sdu = sdu;				// set SDU data
  }

  /**
    Constructor for a broad/uni/multicast service message.

    @param destinations		destinations
    @param sdu			SDU data
  */
  public MCASTSdu(String destinations, String sdu) {
    super(TYPE);				// construct with type
    this.destinations = destinations;		// set SDU destinations
    this.sdu = sdu;				// set SDU data
  }

  /**
    Return the destinations.

    @return		destinations (router letters)
  */
  public String getDestinations() {
    return(destinations);
  }

  /**
    Return the label for an arrow representing a protocol stack SDU in a time
    sequence diagram.

    @return		the label name
  */
  public String getLabel() {
    return type + "(" + destinations + "," + sdu + ")";
  }

  /**
    Return the SDU.

    @return		SDU
  */
  public String getSDU() {
    return(sdu);
  }

  /**
    Set the destinations.

    @param destinations		destinations
  */
  public void setDestinations(String destinations) {
    this.destinations = destinations;
  }

  /**
    Set the SDU.

    @param sdu		SDU
  */
  public void setSDU(String sdu) {
    this.sdu = sdu;
  }

  /**
    Convert SDU to string.

    @return		SDU as string
  */
  public String toString() {
    return(
      "SDU <Type " + type + ", Destinations " + destinations +
      ", Data " + sdu + ">");
  }

}

