// MUXSdu.java

package protocol;				// protocol package

import support.*;				// import Jasper support classes

/**
  This is the class that defines (de)multiplexer service messages.

  @author	Kenneth J. Turner
  @version	1.0 (20th July 2010, KJT): initial version
*/

public class MUXSdu extends PDU {

  /** Service SDU type */
  public final static String TYPE = "DATA";

  /** Service entity */
  public int entity;

  /** Service message */
  public String sdu;

  /**
    Constructor for a source/sink service message.

    @param entity	service entity index
    @param sdu		SDU data
  */
  public MUXSdu(int entity, String sdu) {
    super(TYPE);				// construct with type
    this.entity = entity;			// set entity index
    this.sdu = sdu;				// set SDU data
  }

  /**
    Return the label for an arrow representing a (de)multiplexer SDU in a time
    sequence diagram.

    @return		the label name
  */
  public String getLabel() {
    return(type + "(" + entity + "," + sdu + ")");
  }

  /**
    Convert SDU to string.
  */
  public String toString() {
    return("SDU <Type " + type + ", Entity " + entity + ", Data " + sdu + ">");
  }

}

