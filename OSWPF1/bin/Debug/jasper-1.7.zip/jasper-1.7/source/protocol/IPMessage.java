// IPMessage.java	(C) I. A. Robin, K. J. Turner	01/03/01

package protocol;

import support.*;

public class IPMessage extends PDU {

  int messageID;
  int fragOffset = -1;               // fragment offset
  private boolean dontFrag = false;
  private boolean moreFrags = false;

  public IPMessage(String type, int mid, int length) {
    super(type);
    messageID = mid;
    this.size = length;
  }

  public IPMessage(String type, int mid, int offset, int length) {
    super(type);
    messageID = mid;
    fragOffset = offset;
    this.size = length;
  }

  public void setDontFrag(boolean d) {
    dontFrag = d;
  }

  public boolean dontFrag() {
    return dontFrag;
  }

  public void setMoreFrags(boolean m) {
    moreFrags = m;
  }

  public boolean hasMoreFrags() {
    return moreFrags;
  }

  public boolean matches(PDU pdu) {
    if (pdu == null || pdu.getClass() != IPMessage.class)
      return false;
    IPMessage ipd = (IPMessage)pdu;
    if (type.equals(ipd.type) && source == ipd.getSource()
           && messageID == ipd.messageID
           && (fragOffset < 0 ||
               fragOffset >= 0 &&
               ipd.fragOffset >= fragOffset &&
               ipd.fragOffset < fragOffset + size)) return true;
    return false;
  }

  // return label for arrow representing this ip datagram
  // in a time sequence diagram

  public String getLabel() {
    String label = getID();
    if (fragOffset >= 0) label += moreFrags? " +" : " -";
    return label;
  }

  // return string representing this pdu in actions menu

  public String getID() {
    String id = type + "(" + messageID;
    if (fragOffset >= 0) {
      id += "," + fragOffset;
      if (dontFrag) id += ",D";
    }
    id += "," + size + ")";
    return id;
  }

}
