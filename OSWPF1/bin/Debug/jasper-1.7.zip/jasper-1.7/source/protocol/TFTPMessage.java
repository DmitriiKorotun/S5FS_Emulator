// TFTPMessage.java	(C) K. J. Turner	01/03/01

// Trivial File Transfer Protocol message format

package protocol;				// protocol package

import support.*;				// protocol entity support

public class TFTPMessage extends PDU {		// protocol data unit format

  public TFTPMessage (String type, int seq) {	// construct PDU type/seq
    super (type, seq);				// use generic PDU constructor
  }

  public TFTPMessage (String type, String sdu) { // construct PDU type/SDU
    super (type, sdu);				// use generic PDU constructor
  }

  public TFTPMessage (				// construct PDU type/seq/SDU
   String type, int seq, String sdu) {
    super(type, seq, sdu);			// use generic PDU constructor
  }

  public String getLabel () {			// get PDU "type(contents)"
    String label = type;			// get PDU type
    if (seq >= 0) {				// sequence number present?
      label += "(" + seq;			// append sequence number
      if (sdu.equals (""))			// SDU absent?
        label += ")";				// finish contents
      else					// SDU present
        label += "," + sdu + ")";		// append SDU, finish contents
    }
    else if (!sdu.equals (""))			// no seq no, SDU present?
      label += "(" + sdu + ")";			// append SDU
    return (label);				// return PDU label
  }

}
