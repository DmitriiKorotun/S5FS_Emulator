// CSMAMedium.java

package protocol;				// protocol package

import java.util.Enumeration;			// import Java enumerations
import java.util.HashSet;			// import Java hash sets
import java.util.StringTokenizer;		// import Java string tokenisers
import java.util.Vector;			// import Java vectors

import support.*;				// import Jasper support classes

/**
  This is the class that defines a CSMA/CD medium.

  @author	Kenneth J. Turner
  @version	1.0 (24th July 2010): initial version
*/

public class CSMAMedium extends Medium {

  /** Medium deliver offer */
  private final static String DELIVER = "Deliver ";

  /** Medium name */
  private String mediumName;

  /**
    Constructor for a CSMA/CD medium.

    @param mediumName		medium name
  */
  public CSMAMedium(String mediumName) {
    this.mediumName = mediumName;		// set protocol name
  }

  /**
    Return the PDU currently with the same destination and SDU, in a format such
    as "START(D1) to MAC 1".

    @param description		service description
    @return			corresponding PDU (or null if not found)
  */

  protected PDU getMatchingPDU(String description) {
    description =				// remove "Deliver "
      description.substring(DELIVER.length());
    for (Enumeration enumeration = pdus.elements();
	 enumeration.hasMoreElements(); ) {	// go through PDUs
      CSMAPdu pdu =				// get next PDU
	(CSMAPdu) enumeration.nextElement();
      if (pdu.getDescription().equals(description)) // matching PDU found?
	return(pdu);				// return matched PDU
    }
    return(null);				// return no PDU
  }

  /**
    Get the medium name.

    @return	medium name
  */
  public String getName() {
    return(mediumName);				// return protocol name
  }

  /**
    Return a list of strings describing actions (services) that can be carried
    out in the current state.

    @return			service descriptions
  */
  public Vector<String> getServices() {
    Vector<String> list = new Vector<String>();	// initialise service list
    for (Enumeration enumeration = pdus.elements();
	 enumeration.hasMoreElements(); ) {	// go through PDUs in medium
      PDU pdu = (PDU) enumeration.nextElement();// get PDU
      if (pdu != null) {			// non-null PDU?
	String description = pdu.getID();	// get PDU id
	String destination =			// get PDU destination name
	  pdu.getDestination().getName();
	if (!contains(destination, list))	// nothing for this destination?
	  list.addElement(DELIVER + description + " to " + destination);
      }
    }
    return(list);
  }

  /**
    Check if the given string in contained in the given list.

    @param string	string to search for
    @param list		list to search
    @return		true/false if the medium has no/has PDUs
  */
  public boolean contains(String string, Vector<String> list) {
    for (int i = 0; i < list.size(); i++) {	// go through list
      String text = (String) list.get(i);	// get list text
      if (text.indexOf(string) >= 0)		// text contains string?
	return(true);				// return true immediately
    }
    return(false);				// return false as no match
  }

}

