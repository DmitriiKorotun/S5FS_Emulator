// IPService.java	(C) I. A. Robin, K. J. Turner	04/03/06

package protocol;

import java.util.*;
import support.*;

public class IPService implements ProtocolEntity {

  public static final String DAT_REQ  = "Data Request";

  private ProtocolEntity provider;			// protocol for service
  private Vector providerEvents;
  private String name;
  private int block;					// block seq. no.
  private int messageSize = 400;

  public IPService(String name) {
    this.name = name;
    initialise();
  }

  public void initialise() {
    block = 0;
    providerEvents = new Vector();
  }

  public String getName() {
    return(name);
  }

  public void setProvider(ProtocolEntity provider) {
    this.provider = provider;
  }

  public void setMessageSize(int size) {
    messageSize = size;
  }

  public Vector<ProtocolEvent> receivePDU(PDU pdu) {
    return(new Vector<ProtocolEvent>());
  }

  public void transmitPDU(PDU pdu, ProtocolEntity dest) {
    pdu.setSource(this);
    pdu.setDestination(dest);
    providerEvents = dest.receivePDU(pdu);
  }

  public Vector<String> getServices() {
    Vector<String> list = new Vector<String>();
    list.addElement("Send " + DAT_REQ + "(D" + block + ")");
    return(list);
  }

  public Vector<ProtocolEvent> performService(String s) {
    Vector<ProtocolEvent> events = new Vector<ProtocolEvent>();
    if (s.startsWith("Send " + DAT_REQ)) {
      String sdu = "D" + block;
      PDU pdu = new PDU("DatReq", sdu);
      pdu.size = messageSize;
      transmitPDU(pdu, provider);
      block++;
      events.addElement(new ProtocolEvent(ProtocolEvent.TRANSMIT, pdu));
    }
    for (Enumeration e = providerEvents.elements(); e.hasMoreElements(); )
      events.addElement((ProtocolEvent) e.nextElement());
    return(events);
  }

}
