// SMTP.java	(C) K. J. Turner, P. K. Johnson	04/03/06

// Simple Mail Transfer Protocol

package protocol;

import java.util.*;
import support.*;

public class SMTP extends Protocol {

  private SMTPSender client;
  private SMTPReceiver server;

  public SMTP() {
    medium = new Medium();
    client = new SMTPSender(medium, "Client");
    server = new SMTPReceiver(medium, "Server");
    client.setPeer(server);
    server.setPeer(client);
    entities = new Vector<ProtocolEntity>();
    entities.addElement(client);
    entities.addElement(medium);
    entities.addElement(server);
  }

}
