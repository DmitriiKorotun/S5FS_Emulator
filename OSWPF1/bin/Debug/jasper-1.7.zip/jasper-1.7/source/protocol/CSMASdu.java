// CSMASdu.java

package protocol;				// protocol package

import support.*;				// import Jasper support classes

/**
  This is the class that defines (de)multiplexer service messages.

  @author	Kenneth J. Turner
  @version	1.0 (24th July 2010, KJT): initial version
*/

public class CSMASdu extends PDU {

  /** Service SDU type */
  public final static String DATA = "DATA";

  /** Service retry limit failure */
  public final static String FAIL = "FAIL";

  /**
    Constructor for a source/sink service message.

    @param type		SDU type
    @param sdu		SDU data
  */
  public CSMASdu(String type, String sdu) {
    super(type);				// construct with type
    this.sdu = sdu;				// set SDU data
  }

  /**
    Return the label for an arrow representing a (de)multiplexer SDU in a time
    sequence diagram.

    @return		the label name
  */
  public String getLabel() {
    return(type + "(" + sdu + ")");
  }

  /**
    Convert SDU to string.
  */
  public String toString() {
    return("SDU <Type " + type + ", Data " + sdu + ">");
  }

}

