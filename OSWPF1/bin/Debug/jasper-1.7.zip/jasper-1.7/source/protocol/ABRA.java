// ABRA.java	(C) I. A. Robin, K. J. Turner	04/03/06

package protocol;

import java.util.*;
import support.*;

public class ABRA extends Protocol {

  private ABRAService  abraServA;
  private ABRAProtocol abraProtA;
  private ABRAProtocol abraProtB;
  private ABRAService  abraServB;

  public ABRA() {
    medium    = new Medium();
    abraServA = new ABRAService("User A");
    abraServB = new ABRAService("User B");
    abraProtA = new ABRAProtocol(medium, "Protocol A");
    abraProtB = new ABRAProtocol(medium, "Protocol B");
    abraServA.setProvider(abraProtA);
    abraServB.setProvider(abraProtB);
    abraProtA.setUser(abraServA);
    abraProtA.setPeer(abraProtB);
    abraProtB.setUser(abraServB);
    abraProtB.setPeer(abraProtA);
    entities = new Vector<ProtocolEntity>();
    entities.addElement(abraServA);
    entities.addElement(abraProtA);
    entities.addElement(medium);
    entities.addElement(abraProtB);
    entities.addElement(abraServB);
  }

}
