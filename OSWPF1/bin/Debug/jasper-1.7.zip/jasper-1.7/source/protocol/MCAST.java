// MCAST.java

package protocol;				// protocol package

import java.util.*;				// import Java utility classes

import support.*;				// import Jasper support classes

/**
  This is the main class for simulation of multicasting. It handles broadcast,
  unicast and multicast.

  @author	Kenneth J. Turner
  @version	1.0 (22nd July 2010, KJT): initial version
*/
public class MCAST extends Protocol {

  /** Broadcast service mode */
  public final static int BROADCAST = 0;

  /** Multiple unicast service mode */
  public final static int UNICAST = 1;

  /** Multicast service mode */
  public final static int MULTICAST = 2;

  /** Service entities */
  private static Vector<ProtocolEntity> serviceEntities;

  /** Service mode */
  public static int serviceMode = BROADCAST;

  /** Source */
  private MCASTSource source;

  /** Router A */
  private MCASTRouter userA;

  /** Router B */
  private MCASTRouter userB;

  /** Router C */
  private MCASTRouter userC;

  /** Router D */
  private MCASTRouter userD;

  /** Router E */
  private MCASTRouter userE;

  /** Router F */
  private MCASTRouter userF;

  /**
    Constructor for an MCAST object.
  */
  public MCAST() {
    source = new MCASTSource("Source");		// create source
    userA = new MCASTRouter("Router A");	// create router A
    userB = new MCASTRouter("Router B");	// create router B
    userC = new MCASTRouter("Router C");	// create router C
    userD = new MCASTRouter("Router D");	// create router D
    userE = new MCASTRouter("Router E");	// create router E
    userF = new MCASTRouter("Router F");	// create router F

    serviceEntities = new Vector<ProtocolEntity>();
    serviceEntities.addElement(source);		// add source
    serviceEntities.addElement(userA);		// add router A
    serviceEntities.addElement(userB);		// add router B
    serviceEntities.addElement(userC);		// add router C
    serviceEntities.addElement(userD);		// add router D
    serviceEntities.addElement(userE);		// add router E
    serviceEntities.addElement(userF);		// add router F
    entities = serviceEntities;			// store entities for protocol
  }

  /**
    Return a protocol event with the given comment.

    @param entity	protocol entity
    @param comment	protocol comment
    @return		protocol event
  */
  public static ProtocolEvent comment(ProtocolEntity entity, String comment) {
    return(new ProtocolEvent(ProtocolEvent.COMMENT, entity, comment));
  }

  /**
    Get an entity by letter.

    @param entityLetter		entity letter ('A', etc.)
    @return			protocol entity
  */
  public static ProtocolEntity getEntity(char entityLetter) {
    int index = entityLetter - 'A' + 1;
    return(serviceEntities.get(index));		// return entity for index
  }

  /**
    Get an entity's SDUs.

    @param entityLetter	entity	router letter ('A', etc.)
    @return			SDU held by router
  */
  public static Vector<MCASTSdu> getSDUs(char entityLetter) {
    ProtocolEntity entity =			// get entity for letter
      getEntity(entityLetter);
    return(((MCASTRouter) entity).getSDUs());	// return SDUs
  }

  /**
    Set a parameter of the MCAST simulation.

    @param parameter	parameter name (broadcast, multicast, unicast)
    @param value	parameter value
  */
  public void setParameter(String parameter, String value) {
    if (parameter.equals("serviceMode")) {	// service count?
      if (value.equalsIgnoreCase("broadcast"))	// broadcast?
	serviceMode = BROADCAST;		// note as broadcast
      else if (value.equalsIgnoreCase("multicast")) // multicast?
	serviceMode = MULTICAST;		// note as multicast
      else if (value.equalsIgnoreCase("unicast")) // unicast?
	serviceMode = UNICAST;			// note as unicast
      else					// not broad/multi/unicast
	System.err.println(			// report error
	  "MUX.setParameter: invalid service mode '" + value + "'");
    }
  }

}

