// CSMAPdu.java

package protocol;				// protocol package

import support.*;				// import Jasper support classes

/**
  This is the class that defines CSMA/CD protocol messages.

  @author	Kenneth J. Turner
  @version	1.0 (27th July 2010, KJT): initial version
*/
public class CSMAPdu extends PDU {

  /** Protocol transmission finished PDU */
  public final static String FINISH = "FINISH";

  /** Protocol transmission collision PDU */
  public final static String JAM = "JAM";

  /** Protocol transmission started PDU */
  public final static String START = "START";

 /**
    Constructor for a CSMA/CD PDU for the given type and with the given SDU.

    @param type		PDU type
    @param sdu		PDU payload as SDU
  */
  public CSMAPdu(String type, String sdu) {
    super(type, sdu);				// construct PDU
  }

  /**
    Return the PDU description with destination and SDU, in a format such as
    "START(D1) to MAC 1".

    @return		PDU description
  */
  public String getDescription() {
    return(
      getLabel() + " to " + getDestination().getName());
  }

  /**
    Return the label for an arrow representing a CSMA/CD PDU in a time sequence
    diagram.

    @return		PDU label
  */
  public String getLabel() {
    return(					// return PDU as string
      sdu == null || sdu.length() == 0 ? type : type + "(" + sdu + ")");
  }

  /**
    Convert PDU to string.

    @return		PDU as string
  */
  public String toString() {
    return(					// return PDU as string
      sdu == null || sdu.length() == 0 ? type : type + "(" + sdu + ")");
  }

}

