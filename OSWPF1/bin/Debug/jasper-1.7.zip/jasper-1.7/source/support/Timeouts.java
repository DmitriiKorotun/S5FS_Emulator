// Timeouts.java

package support;				// protocol support package

/**
  This is the base interface for timeouts, implemented by protocols that need
  them.

  @author	Iain A. Robin, Kenneth J. Turner
  @version	1.0 (1st September 1999, IAR): initial version
  <br/>		1.5 (27th July 2010, KJT): minor tidying
*/
public interface Timeouts {

  /**
    Report whether a specified PDU type has an associated timer.
  */
  public boolean hasTimer(String type);

  /**
    Set the timer for a specified PDU.

    @param pdu		PDU
    @param enabled	whether the timer is enabled
  */
  public void setTimer(PDU pdu, boolean enabled);

}
