// ProtocolEvent.java

package support;				// protocol support package

/**
  This is the class for protocol events.

  @author	Iain A. Robin, Kenneth J. Turner
  @version	1.0 (1st September 1999, IAR): initial version
  <br/>		1.4 (9th March 2006, KJT): updated for JDK 1.5
  <br/>		1.5 (22nd July 2010, KJT): minor tidying; addition of TRAVERSE
		  event
*/
public class ProtocolEvent {

  /** Protocol event user -> protocol */
  public final static int SEND = 0;

  /** Protocol event protocol -> user */
  public final static int DELIVER = 1;

  /** Protocol event protocol -> medium */
  public final static int TRANSMIT = 2;

  /** Protocol event medium -> protocol */
  public final static int RECEIVE = 3;

  /** Protocol event medium fragmentation */
  public final static int FRAGMENT = 4;

  /** Protocol event medium loss */
  public final static int LOSE = 5;

  /** Protocol event timeout and retransmission */
  public final static int TIMEOUT = 6;

  /** Protocol event arbitrary comment */
  public final static int COMMENT = 7;

  /** Protocol event entity -> entity */
  public final static int TRAVERSE = 8;

  /** Protocol event protocol data unit */
  private PDU pdu = null;

  /** Protocol event type */
  private int eventType;

  /** Protocol event comment */
  private String comment = "";

  /** Protocol event target */
  private ProtocolEntity target;

  /**
    Constructor for a protocol event.

    @param type		event type
    @param pdu		protocol data unit
   */
  public ProtocolEvent(int type, PDU pdu) {
    eventType = type;
    this.pdu = pdu;
  }

  /**
    Constructor for a protocol event.

    @param type		event type
    @param target	target entity
    @param comment	event comment
  */
  public ProtocolEvent(int type, ProtocolEntity target, String comment) {
    eventType = type;
    this.target = target;
    this.comment = comment;
  }

  /**
    Get the comment attribute of a protocol event.

    @return		comment
  */
  public String getComment() {
    return(comment);
  }

  /**
    Get the PDU attribute of a protocol event

    @return   The pDU value
  */
  public PDU getPDU() {
    return(pdu);
  }

  /**
    Get the target attribute of a protocol event.

    @return		target
  */
  public ProtocolEntity getTarget() {
    return(target);
  }

  /**
    Get the type attribute of a protocol event.

    @return   The type value
  */
  public int getType() {
    return(eventType);
  }

  /**
    Convert to a string representation of a protocol event.

    @return   A string representation of the object.
  */
  public String toString() {
    return(
      "Event <Type " + eventType + (pdu != null ?
      " " + pdu : " Target " + target.getName() + " Comment " + comment) +
      ">");
  }

}

