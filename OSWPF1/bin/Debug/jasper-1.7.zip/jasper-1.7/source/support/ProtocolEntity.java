// ProtocolEntity.java

package support;				// Jasper support package

import java.util.Vector;			// import Java vectors

/**
  This is the base interface for protocol entities.

  @author	Iain A. Robin, Kenneth J. Turner
  @version	1.0 (1st September 1999, IAR): initial version
  <br/>		1.4 (9th March 2006, KJT): updated for JDK 1.5
  <br/>		1.5 (22nd July 2010, KJT): minor tidying
*/
public interface ProtocolEntity {

  public String getName();

  public Vector<String> getServices();

  public void initialise();

  public Vector<ProtocolEvent> performService(String s);

  public Vector<ProtocolEvent> receivePDU(PDU pdu);

  public void transmitPDU(PDU pdu, ProtocolEntity dest);

}
