// PDU.java

package support;				// protocol support package

/**
  This is the main class for protocol simulator.

  @author	Iain A. Robin, Kenneth J. Turner
  @version	1.0 (1st September 1999, IAR): initial version
  <br/>		1.4 (9th March 2006, KJT): updated for JDK 1.5
  <br/>		1.5 (22nd July 2010, KJT): commenting and minor tidying
*/
public class PDU {

  /** Protocol Data Unit type */
  public String type = "";

  /** Protocol Data Unit sequence number (-1 = none) */
  public int seq = -1;

  /** Protocol Data Unit user data length */
  public int size = 0;

  /** Protocol Data Unit payload as Service Data Unit */
  public String sdu = "";

  /** Protocol Data Unit source */
  public ProtocolEntity source;

  /** Protocol Data Unit destination */
  public ProtocolEntity destination;

  /**
    Constructor for a PDU object.
  */
  public PDU() {
  }

  /**
    Constructor for a PDU object.

    @param type		PDU type
  */
  public PDU(String type) {
    this.type = type;
  }

  /**
    Constructor for a PDU object.

    @param type		PDU type
    @param seq		PDU sequence number
  */
  public PDU(String type, int seq) {
    this.type = type;
    this.seq = seq;
  }

  /**
    Constructor for a PDU object.

    @param type		PDU type
    @param sdu		PDU payload as SDU
  */
  public PDU(String type, String sdu) {
    this.type = type;
    this.sdu = sdu;
  }

  /**
    Constructor for a PDU object.

    @param type		PDU type
    @param seq		PDU sequence number
    @param sdu		PDU payload as SDU
  */
  public PDU(String type, int seq, String sdu) {
    this.type = type;
    this.seq = seq;
    this.sdu = sdu;
  }

  /**
    Get the destination attribute of a PDU object.

    @return		PDU destination
  */
  public ProtocolEntity getDestination() {
    return(destination);
  }

  /**
    Get the identifier attribute of a PDU object.

    @return		PDU identifier (i.e. label)
  */
  public String getID() {
    return(getLabel());
  }

  /**
    Get the label attribute of the PDU object, identifying an arrow in a time
    sequence diagram.

    @return		PDU label
  */
  public String getLabel() {
    String label = type;			// parameter if any in brackets
    if (seq >= 0)
      label += "(" + seq + ")";			// show seq number parameter
    else if (!sdu.equals(""))
      label += "(" + sdu + ")";			// show SDU parameter
    return(label);
  }

  /**
    Get the SDU attribute of a PDU object.

    @return		PDU payload as SDU
  */
  public String getSDU() {
    return(sdu);
  }

  /**
    Get the source attribute of a PDU object.

    @return   The source value
  */
  public ProtocolEntity getSource() {
    return(source);
  }

  /**
    Check whether a PDU matches this one.

    @param pdu		PDU to be checked
    @return		true/false if PDU matches/does not match this one
  */
  public boolean matches(PDU pdu) {
    if (pdu == null)
      return(false);
    return(
      type.equals(pdu.type) && source == pdu.getSource() && seq == pdu.seq);
  }

  /**
    Sets the destination attribute of a PDU object.

    @param destination	PDU destination
  */
  public void setDestination(ProtocolEntity destination) {
    this.destination = destination;
  }

  /**
    Sets the SDU attribute of athe PDU object.
   *
    @param sdu		PDU payload as SDU
   */
  public void setSDU(String sdu) {
    this.sdu = sdu;
  }

  /**
    Set the source attribute of a PDU object.

    @param source	PDU source
  */
  public void setSource(ProtocolEntity source) {
    this.source = source;
  }

  /**
    Convert a PDU to a string representation.

    @return		string representation of a PDU
 */
  public String toString() {
    return ("PDU <Type " + type + ", Seq " + seq + ", Data " + sdu + ">");
  }

}

