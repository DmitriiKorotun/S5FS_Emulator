// FailedTransmission.java

package simulator;

import java.awt.*;
import support.ProtocolEvent;

/**
  This is the class for a failed transmission arrow.

  @author	Kenneth J. Turner
  @version	1.0 (1st September 1999, IAR): initial version <br/>
  <br/>		1.5 (22nd July 2010, KJT): minor tidying
*/
public class FailedTransmission extends TransmissionSymbol {

  private final static int crossSize = 10;

  /**
    Constructor for a traverse transmission arrow.

    @param event	protocol event
    @param lToR		true = left-to-right
    @param column	column
    @param top		top of service primitive
    @param height	height of successful transmission
  */
  public FailedTransmission(
    ProtocolEvent event, boolean lToR, int column, int top, int height) {
    super(event, lToR, column, top, height);
  }

  /**
    Draw a dashed line with cutoff representing failed transmission through
    medium.

    @param g		graphics object
  */
  public void draw(Graphics g) {
    int leftX = inset + col * columnWidth + arrowWidth / 2;
    int rightX = leftX + columnWidth - arrowWidth;
    int midX = (leftX + rightX) / 2;
    int midY = top + height / 2;
    g.setColor(Color.blue);
    if (lToR)
      drawDashedLine(g, leftX, top, midX, midY, dashLength);
    else
      drawDashedLine(g, rightX, top, midX, midY, dashLength);
    // draw a cross to indicate loss of signal
    g.drawLine(midX - crossSize / 2, midY - crossSize / 2,
      midX + crossSize / 2, midY + crossSize / 2);
    g.drawLine(midX + crossSize / 2, midY - crossSize / 2,
      midX - crossSize / 2, midY + crossSize / 2);
    g.setColor(Color.black);
  }

}

