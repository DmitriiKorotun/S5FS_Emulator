// TraverseTransmission.java

package simulator;

import java.awt.*;				// import Java AWT classes

import support.*;				// import Jasper protocol event

/**
  This is the class for a traverse transmission arrow.

  @author	Kenneth J. Turner
  @version	1.5 (22nd July 2010, KJT): minor tidying
*/
public class TraverseTransmission extends TransmissionSymbol {

  /** Number of columns to traverse */
  private int columns;

  /**
    Constructor for a traverse transmission arrow.

    @param event	protocol event
    @param lToR		true = left-to-right
    @param source	source column
    @param columns	columns
    @param top		top of service primitive
    @param height	height of successful transmission
  */
  public TraverseTransmission(
    ProtocolEvent event, boolean lToR, int source, int columns, int top,
     int height) {
    super(event, lToR, source, top, height);
    this.columns = columns;
  }

  /**
    Paint the traverse transmission as a dashed line representing transmission
    across the intervening columns.

    @param g		graphics object
  */
  public void draw(Graphics g) {
    int leftX = inset + col * columnWidth + arrowWidth / 2;
    int rightX = leftX + columns*columnWidth - arrowWidth;
    g.setColor(Color.blue);
    if (lToR)
      drawDashedLine(g, leftX, top, rightX, top + height, dashLength);
    else
      drawDashedLine(g, rightX, top, leftX, top + height, dashLength);
    g.setColor(Color.black);
  }

}

