// TransmissionSymbol.java

package simulator;

import java.awt.*;
import support.ProtocolEvent;

/**
  This is the class for a general transmission symbol.

  @author	Iain A. Robin, Kenneth J. Turner
  @version	1.0 (1st September 1999, IAR): initial version <br/>
  <br/>		1.5 (22nd July 2010, KJT): minor tidying
*/
public abstract class TransmissionSymbol extends TSDSymbol {

  /** Left-to-right (if true, else right-to-left) */
  protected boolean lToR;

  /** Dash length */
  protected int dashLength = 6;

  /**
    Constructor for a transmission symbol

    @param event	protocol event
    @param lToR		left-to-right (if true, else right-to-left)
    @param col		column
    @param top		top of service primitive
    @param height	height of successful transmission
  */
  public TransmissionSymbol(
    ProtocolEvent event, boolean lToR, int col, int top, int height) {
    super(event, col, top);
    this.lToR = lToR;
    this.height = height;
  }

  /**
    Draw a dashed line from (x1, y1) to (x2, y2) using the given dash length for
    the lines and graps of the dash.

    @param g		graphics object
    @param x1		initial X-coordinate
    @param y1		initial Y-coordinate
    @param x2		final X-coordinate
    @param y2		final Y-coordinate
    @param dashLength	dash length
  */
  protected void drawDashedLine(
    Graphics g, int x1, int y1, int x2, int y2, int dashLength) {
    float x0 = x1;
    float y0 = y1;
    float x = 0.0f;
    float y = 0.0f;
    float s = 0.0f;
    int deltaX = x2 - x1;
    int deltaY = y2 - y1;
    float length = (float) (Math.sqrt(deltaX * deltaX + deltaY * deltaY));
    float dx = dashLength * deltaX / length;
    float dy = dashLength * deltaY / length;
    x += dx / 2;
    y += dy / 2;
    float ds = (float) (Math.sqrt(dx * dx + dy * dy));
    while (s <= length - ds) {
      g.drawLine(
	Math.round(x + x0), Math.round(y + y0),
	Math.round(x + x0 + dx), Math.round(y + y0 + dy));
      x += 2 * dx;
      y += 2 * dy;
      s += 2 * ds;
    }
  }

  /**
    Empty draw method to be overridden.

    @param g		graphics object
  */
  public abstract void draw(Graphics g);

}

