// TSDSymbol.java

package simulator;

import java.awt.*;
import support.ProtocolEvent;

/**
  This is the class for a general time sequence diagram symbol.

  @author	Kenneth J. Turner
  @version	1.0 (1st September 1999, IAR): initial version <br/>
  <br/>		1.5 (22nd July 2010, KJT): minor tidying
*/
public abstract class TSDSymbol {

  /** Y-coordinate for symbol top */
  protected int top;

  /** Destination column number */
  protected int col;

  /** Symbol height */
  protected int height = 15;

  /** Inset around diagram */
  protected static int inset;

  /** Diagram column width */
  protected static int columnWidth;

  /** Primitive arrow width */
  protected static int arrowWidth;

  /** Protocol event */
  protected ProtocolEvent event;

  /**
    Constructor for the TSDSymbol object
   *
    @param event	protocol event
    @param col		symbol column
    @param top		symbol top
   */
  public TSDSymbol(ProtocolEvent event, int col, int top) {
    this.event = event;
    this.col = col;
    this.top = top;
  }

  /**
    Sets the parameters attribute of the TSDSymbol class

    @param i  The new parameters value
    @param c  The new parameters value
    @param w  The new parameters value
  */
  public static void setParameters(int i, int c, int w) {
    inset = i;
    columnWidth = c;
    arrowWidth = w;
  }

  /**
    Get the event attribute of a time sequence diagram symbol.

    @return   The event value
  */
  public ProtocolEvent getEvent() {
    return event;
  }

  /**
    Get the top attribute of a time sequence diagram symbol.

    @return   The top value
  */
  public int getTop() {
    return top;
  }

  /**
    Get the column attribute of a time sequence diagram symbol.

    @return   The col value
  */
  public int getCol() {
    return col;
  }

  /**
    Get the height attribute of a time sequence diagram symbol.

    @return   The height value
  */
  public int getHeight() {
    return height;
  }

  /**
    Empty draw method to be overridden.

    @param g		graphics object
  */
  public abstract void draw(Graphics g);

}

