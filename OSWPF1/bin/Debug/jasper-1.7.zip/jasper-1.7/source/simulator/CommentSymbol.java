// CommentSymbol.java	(C) I. A. Robin, K. J. Turner	08/03/06

package simulator;

import java.awt.*;
import support.ProtocolEvent;

public class CommentSymbol extends TSDSymbol {

  private boolean lToR;
  private String label;

  public CommentSymbol(ProtocolEvent event, String label,
		       boolean lToR, int col, int top) {
    super(event, col, top);
    this.lToR = lToR;
    this.label = label;
    height = 25;
  }

  public CommentSymbol(ProtocolEvent event, String label,
		       boolean lToR, int col, int top, int height) {
    super(event, col, top);
    this.lToR = lToR;
    this.label = label;
    this.height = height;
  }

  public void draw(Graphics g) {
    g.setFont(TimeSequenceDiagram.labelFont);
    FontMetrics fm = g.getFontMetrics(TimeSequenceDiagram.labelFont);
    if (label.equals("Timeout"))
      g.setColor(TimeSequenceDiagram.timeoutColour);
    else
      g.setColor(TimeSequenceDiagram.commentColour);
    int labelWidth = fm.stringWidth(label);
    int labelHeight = fm.getHeight();
    int xPos = lToR ?
      inset + 10 + col*columnWidth :
      inset - 10 + (col + 1)*columnWidth - labelWidth;
    //int xPos = lToR ? 2*inset + col*columnWidth :
    //           (col + 1)*columnWidth - labelWidth;
    g.drawString(label, xPos, top + height - labelHeight);
    g.setColor(Color.black);
  }

}
