// SpaceFiller.java	(C) I. A. Robin, K. J. Turner	08/11/00

package simulator;

import java.awt.*;

public class SpaceFiller extends TSDSymbol {

  // creates a gap between symbols in Time Sequence Diagram
  // to avoid overlapping

  public SpaceFiller(int col, int top) {
    super(null, col, top);
  }

  // do nothing!

  public void draw(Graphics g) {
  }

}
