// InsetPanel.java	(C) I. A. Robin, K. J. Turner	08/11/00

package simulator;

import java.awt.*;

public class InsetPanel extends Panel {

  public InsetPanel() {
  }

  public Insets getInsets() {
    return new Insets(0, 10, 0, 10);
  }

}
