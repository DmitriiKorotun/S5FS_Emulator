// SuccessfulTransmission.java

package simulator;

import java.awt.*;				// import Java AWT classes

import support.*;				// import Jasper protocol event

/**
  This is the class for a successful transmission arrow.

  @author	Iain A. Robin, Kenneth J. Turner
  @version	1.0 (1st September 1999, IAR): initial version <br/>
  <br/>		1.5 (22nd July 2010, KJT): minor tidying
*/
public class SuccessfulTransmission extends TransmissionSymbol {

  /**
    Constructor for a successful transmission arrow.

    @param event	protocol event
    @param lToR		true = left-to-right
    @param col		column
    @param top		top of service primitive
    @param height	height of successful transmission
  */
  public SuccessfulTransmission(
    ProtocolEvent event, boolean lToR, int col, int top, int height) {
    super(event, lToR, col, top, height);
  }

  /**
    Paint the successful transmission as a dashed line representing transmission
    through the medium.

    @param g		graphics object
  */
  public void draw(Graphics g) {
    int leftX = inset + col * columnWidth + arrowWidth / 2;
    int rightX = leftX + columnWidth - arrowWidth;
    g.setColor(Color.blue);
    if (lToR)
      drawDashedLine(g, leftX, top, rightX, top + height, dashLength);
    else
      drawDashedLine(g, rightX, top, leftX, top + height, dashLength);
    g.setColor(Color.black);
  }

}

